/*
 * HWadaptor.h
 *
 *  Created on: Feb 21, 2010
 *      Author: dirk
 */

#ifndef HWADAPTOR_H_
#define HWADAPTOR_H_

#include "target.h"

#endif /* HWADAPTOR_H_ */

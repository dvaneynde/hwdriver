/*
 * target.h
 *
 *  Created on: Feb 21, 2010
 *      Author: dirk
 */

#ifndef TARGET_H_
#define TARGET_H_

#undef OSX

#endif /* TARGET_H_ */

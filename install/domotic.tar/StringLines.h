/*
 * StringLines.h
 *
 *  Created on: Feb 21, 2010
 *      Author: dirk
 */

#ifndef STRINGLINES_H_
#define STRINGLINES_H_

int getLineCount(char *buffer);
int parseStringbyLines(char *buffer, char ***string);


#endif /* STRINGLINES_H_ */
